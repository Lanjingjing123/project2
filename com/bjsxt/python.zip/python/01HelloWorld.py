print("hello world")

# a=3.14
# a='a'
# flag = True
# print(a)
# print(type(a))
#
# print(flag)
# print(type(flag))
#
# # python里面没有null 只有None
# str = None
#
# # 定义一个虚数
# print(complex(1,2))
#
# import keyword
# print(keyword.kwlist)
#
# # 占位符
# print("%d*%d=%d"%(100,200,300))
#
# abc="hello"
# print("%s,world"%"hello")
# print("%s,world"%(abc))
#
# f=123.456
# print("%.2f"%(f))
# s=input("请输入数字")
# print(s)

# print(10/3)
# print(10//3)
# print(2**3)
# print(3**3)
